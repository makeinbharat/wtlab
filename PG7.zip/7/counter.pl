#!D:\xampp\perl\bin\perl.exe
use CGI':standard';
print("content-type:text/html\n\n");

$file = "./cnt.txt";
if(open(FILE,'<'.$file)){
    $no_acc = <FILE>;
    close(FILE);
    if(open(FILE,'>'.$file)){
        $no_acc++;
        print FILE $no_acc;
        close(FILE);
        print("no of visitors: ", $no_acc);
    }
    else{
        print("couldn't write data on file");
    }
}
else{
    print("couldn't open file");
}

exit(0);