<?php

include_once('fix_mysql.inc.php');
$con = new mysqli("localhost","root","","wtlab") or die(mysql_error());

$sql = $con -> query("select * FROM data");

mysql_close($con);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fluentdesignforweb.github.io/fluent.css" type="text/css" rel="stylesheet">
    <title>Document</title>
    <style>
        a:before{
            display: none;
        }
    </style>
</head>

<body style="background: #f4f4f4;">
    <div class='column large4 medium8 small12 center' style='margin-top: 100px; background: #f4f4f4; border-radius: 12px; padding: 5vh 6vh; box-shadow: 6px 6px 8px #acacac44, -6px -6px 8px #ffffff'>
        <table style="border-radius: 12px;">
            <thead>
                <tr style="background: #0e1e1e; color: #fcfcfc">
                    <td>First Name</td>
                    <td>Last Name</td>
                    <td>Age</td>
                </tr>
            </thead>
            <tbody>
                <?php
                    while($row = mysql_fetch_array($sql))
                        {
                            
                            echo "<tr>";
                            echo "<td>" . $row['fname'] . "</td>";
                            echo "<td>" . $row['lname'] . "</td>";
                            echo "<td>" . $row['age'] . "</td>";
                            echo "</tr>";
                        }
                ?>
            </tbody>
        </table>
        <br/><br/>
        <a href='./index.php'><button class='primary_blue' style='border-radius: 4px; margin: 0px;'>Add Another Record</button></a>
    </div>
</body>
