<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    include_once('fix_mysql.inc.php');

    $con = mysql_connect("localhost","root","") or die(mysql_error());
    mysql_select_db ("wtlab") or die(mysql_error());
    $sql="insert into data (fname, lname, age, address, pin) values ('$_POST[fname]', '$_POST[lname]', '$_POST[age]', '$_POST[address]', '$_POST[pin]')";
    if (!mysql_query($sql,$con))
    {
    die('Error: ' . mysql_error());
    }
    echo "
        
        <div class='column large4 medium8 small12 center' style='margin-top: 100px; padding: 5vh 6vh; background: #f4f4f4; border-radius: 12px; box-shadow: 6px 6px 8px #acacac44, -6px -6px 8px #ffffff'>
            <h3>Record Added Successfully</h3>
            <a href='./index.php'><button class='primary_blue' style='border-radius: 4px; margin: 0px;'>Add Another Record</button></a>
            <a href='./result.php'><button class='primary_blue' style='border-radius: 4px; margin: 0px;'>See All Records</button></a>
        </div>
    
    ";
    mysql_close($con);    
}
else{
    echo "
        
        <div class='column large4 medium8 small12 center' style='margin-top: 100px; padding: 5vh 6vh; background: #f4f4f4; border-radius: 12px; box-shadow: 6px 6px 8px #acacac44, -6px -6px 8px #ffffff'>
            <h3>Record Not Added</h3>
            <a href='./index.php'><button class='primary_blue' style='border-radius: 4px; margin: 0px;'>Add Another Record</button></a>
            <a href='./result.php'><button class='primary_blue' style='border-radius: 4px; margin: 0px;'>See All Records</button></a>
        </div>
    
    ";
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fluentdesignforweb.github.io/fluent.css" type="text/css" rel="stylesheet">
    <title>Document</title>
    <style>
        a:before{
            display: none;
        }
    </style>
</head>

<body style="background: #f4f4f4;">

</body>