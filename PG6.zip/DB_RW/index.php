<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fluentdesignforweb.github.io/fluent.css" type="text/css" rel="stylesheet">

    <style>
        .in_bg{
            background: inherit;
            border-radius: 0px;
        }
        label{
            font-weight: 700;
        }
        a:before{
            display: none;
        }
    </style>
    <title>Document</title>
</head>
<body style="background: #f4f4f4;">
    <form action="./input.php" method="post" class="column large4 medium8 small12 center" style="margin-top: 100px; padding: 5vh 6vh; background: #f4f4f4; border-radius: 12px; box-shadow: 6px 6px 8px #acacac44, -6px -6px 8px #ffffff">
        <h3>Add Student Record</h3><br/>
        <input type="text" name="fname" class="btm_brdr in_bg" required /><br/>
        <label>First Name</label><br/><br/>
        <input type="text" name="lname" class="btm_brdr in_bg" required /><br/>
        <label>Last Name</label><br/><br/>
        <input type="number" name="age" class="btm_brdr in_bg" required /><br/>
        <label>Age</label><br/><br/>
        <input type="text" name="address" class="btm_brdr in_bg" required /><br/>
        <label>Address</label><br/><br/>
        <input type="number" name="pin" class="btm_brdr in_bg" required /><br/>
        <label>Pincode</label><br/><br/>
        <button class="primary_blue small" style="border-radius: 4px; margin: 0px;">Submit</button>
        <br/><br/><br/><br/>
        <a href='./result.php'><button class='secondary_green' style='border-radius: 4px; margin: 0px;'>See All Records</button></a>
    </form>
</body>
</html>